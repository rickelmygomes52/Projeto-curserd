# Projeto Curserd Character Sheet

## Overview

This is a client-side character sheet application for a tabletop RPG called "Projeto Curserd" (Cursed Project). The application is built as a simple, single-page web application that allows players to create, edit, and manage their character information with automatic local storage persistence. The application features a dark theme with yellow/gold accents, comprehensive skill system, dice rolling functionality, and character image support.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (January 2025)

**Major Architecture Update:**
- Evolved from single-page to multi-page application structure
- Updated color scheme to dark purple theme (#0b0b14 background, #aa6cff accents)
- Added navigation system between three main pages: Home, Campaigns, Character Sheet

**New Features Added:**
- Multi-page navigation system (index.html, campanhas.html, ficha.html)
- Campaign management system with full CRUD operations
- Character sheet export/import functionality (JSON format)
- File-based character image upload (replaces URL input)
- Enhanced attack creator with persistent storage
- Comprehensive dice rolling system (d4, d6, d8, d10, d20)
- Auto-save functionality with visual indicators
- Responsive design with mobile support

**Technical Improvements:**
- Centralized CSS styling (style.css) for consistent theming
- Local storage persistence for all data including images and campaigns
- Modular JavaScript architecture with separate managers
- Enhanced form validation and error handling

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: Built with vanilla HTML, CSS, and JavaScript
- **Client-side only**: No backend server required, runs entirely in the browser
- **Local Storage**: Uses browser's localStorage API for data persistence
- **Responsive Design**: CSS Grid and Flexbox for adaptive layouts

### Key Technologies
- **HTML5**: Semantic markup with form elements
- **CSS3**: Modern styling with custom properties, grid, and animations
- **Vanilla JavaScript**: ES6+ classes and modern DOM APIs
- **Google Fonts**: External font resources (Creepster, Roboto)

## Key Components

### 1. Character Sheet Form (`index.html`)
- **Purpose**: Main user interface for character data input
- **Structure**: Organized into logical sections (Identity, Attributes, etc.)
- **Form Elements**: Text inputs, number inputs, and other form controls
- **Accessibility**: Proper labels and semantic HTML structure

### 2. Data Management (`script.js`)
- **CharacterSheet Class**: Main application controller
- **Auto-save Functionality**: Debounced saving to prevent excessive localStorage writes
- **Data Validation**: Form validation and input sanitization
- **Event Handling**: Unified event system for form interactions

### 3. Visual Design (`styles.css`)
- **Dark Theme**: Horror/gothic aesthetic with dark backgrounds
- **Custom Typography**: Creepster font for headers, Roboto for content
- **Visual Effects**: Glowing text effects and atmospheric background gradients
- **Responsive Layout**: Mobile-first approach with flexible grid systems

## Data Flow

### Input Processing
1. User interacts with form elements
2. Event listeners capture input changes
3. Data validation occurs in real-time
4. Changes trigger auto-save mechanism

### Storage System
1. Form data is serialized to JSON
2. Data is stored in browser's localStorage
3. Auto-save indicators provide user feedback
4. Data persists between browser sessions

### Loading Process
1. Application initializes on page load
2. Existing data is retrieved from localStorage
3. Form fields are populated with saved values
4. User interface is ready for interaction

## External Dependencies

### Font Resources
- **Google Fonts API**: Loads Creepster and Roboto font families
- **CDN Delivery**: Fonts served from Google's content delivery network
- **Fallback Strategy**: Generic font families as fallbacks

### Browser APIs
- **localStorage**: For client-side data persistence
- **DOM Events**: For user interaction handling
- **Form Validation API**: For input validation

## Deployment Strategy

### Static Hosting
- **No Server Required**: Can be deployed to any static file hosting service
- **CDN Compatible**: Works well with content delivery networks
- **Local Development**: Can run directly from file system for development

### Hosting Options
- **GitHub Pages**: Suitable for version-controlled deployment
- **Netlify/Vercel**: Modern static hosting with CI/CD capabilities
- **Traditional Web Hosting**: Compatible with any web server

### Performance Considerations
- **Minimal Dependencies**: Only external fonts loaded from CDN
- **Client-side Processing**: No server requests after initial load
- **Local Storage**: Fast data access without network calls
- **Progressive Enhancement**: Works without JavaScript for basic functionality

### Browser Compatibility
- **Modern Browsers**: Targets ES6+ compatible browsers
- **localStorage Support**: Requires browsers with localStorage API
- **CSS Grid/Flexbox**: Uses modern layout techniques
- **Graceful Degradation**: Basic functionality available without advanced features