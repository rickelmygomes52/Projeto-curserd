/**
 * Projeto Curserd Character Sheet
 * Local data persistence and form management
 */

class CharacterSheet {
  constructor() {
    this.storageKey = 'curserd_character_sheet';
    this.saveTimeout = null;
    this.saveIndicator = document.getElementById('saveIndicator');
    this.saveText = document.getElementById('saveText');
    this.form = document.getElementById('characterForm');
    
    this.init();
  }

  /**
   * Initialize the character sheet
   */
  init() {
    this.loadCharacterData();
    this.bindEvents();
    this.setupFormValidation();
    this.setupRangeSlider();
    
    // Show initial save indicator
    this.showSaveIndicator('Dados carregados');
  }

  /**
   * Setup special event handlers
   */
  setupRangeSlider() {
    // Handle file input for character image
    const fileInput = document.getElementById('imagemFile');
    if (fileInput) {
      fileInput.addEventListener('change', (e) => {
        // Save the file name for reference
        const fileName = e.target.files[0]?.name || '';
        localStorage.setItem(this.storageKey + '_image_name', fileName);
        this.handleInputChange(e);
      });
    }

    // Handle select changes
    const selectElements = this.form.querySelectorAll('select');
    selectElements.forEach(select => {
      select.addEventListener('change', (e) => {
        this.handleInputChange(e);
      });
    });
  }

  /**
   * Bind event listeners to form elements
   */
  bindEvents() {
    // Listen for input changes on all form elements
    this.form.addEventListener('input', (e) => {
      this.handleInputChange(e);
    });

    // Listen for checkbox changes
    this.form.addEventListener('change', (e) => {
      if (e.target.type === 'checkbox') {
        this.handleInputChange(e);
      }
    });

    // Handle form submission (prevent default)
    this.form.addEventListener('submit', (e) => {
      e.preventDefault();
    });

    // Auto-save on page unload
    window.addEventListener('beforeunload', () => {
      this.saveCharacterData();
    });

    // Handle visibility change (save when tab becomes hidden)
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.saveCharacterData();
      }
    });
  }

  /**
   * Handle input changes with debounced saving
   */
  handleInputChange(event) {
    const element = event.target;
    
    // Validate numeric inputs
    if (element.type === 'number') {
      this.validateNumericInput(element);
    }

    // Clear existing save timeout
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
    }

    // Show saving indicator
    this.showSaveIndicator('Salvando...', 'saving');

    // Set new save timeout (debounced save after 500ms)
    this.saveTimeout = setTimeout(() => {
      this.saveCharacterData();
      this.showSaveIndicator('Dados salvos automaticamente');
    }, 500);
  }

  /**
   * Validate numeric input fields
   */
  validateNumericInput(element) {
    const value = parseInt(element.value);
    const min = parseInt(element.min) || 0;
    const max = parseInt(element.max) || 999;

    if (isNaN(value)) {
      element.value = '';
      return;
    }

    if (value < min) {
      element.value = min;
    } else if (value > max) {
      element.value = max;
    }
  }

  /**
   * Setup form validation
   */
  setupFormValidation() {
    const numericInputs = this.form.querySelectorAll('input[type="number"]');
    
    numericInputs.forEach(input => {
      input.addEventListener('blur', (e) => {
        this.validateNumericInput(e.target);
      });

      // Prevent invalid characters
      input.addEventListener('keypress', (e) => {
        const char = String.fromCharCode(e.which);
        if (!/[0-9]/.test(char) && e.which !== 8 && e.which !== 9) {
          e.preventDefault();
        }
      });
    });
  }

  /**
   * Save character data to localStorage
   */
  saveCharacterData() {
    try {
      const formData = new FormData(this.form);
      const characterData = {};

      // Convert FormData to object
      for (let [key, value] of formData.entries()) {
        if (value !== '') {
          characterData[key] = value;
        }
      }

      // Handle checkbox separately (as it won't appear in FormData if unchecked)
      const checkboxes = this.form.querySelectorAll('input[type="checkbox"]');
      checkboxes.forEach(checkbox => {
        characterData[checkbox.name] = checkbox.checked;
      });

      // Save to localStorage
      localStorage.setItem(this.storageKey, JSON.stringify(characterData));
      
      return true;
    } catch (error) {
      console.error('Error saving character data:', error);
      this.showSaveIndicator('Erro ao salvar', 'error');
      return false;
    }
  }

  /**
   * Load character data from localStorage
   */
  loadCharacterData() {
    try {
      const savedData = localStorage.getItem(this.storageKey);
      
      if (!savedData) {
        return false;
      }

      const characterData = JSON.parse(savedData);
      
      // Populate form fields
      Object.entries(characterData).forEach(([key, value]) => {
        const element = this.form.querySelector(`[name="${key}"]`);
        
        if (element) {
          if (element.type === 'checkbox') {
            element.checked = value === true || value === 'true';
          } else {
            element.value = value;
          }
        }
      });

      // Load saved image data
      const savedImageData = localStorage.getItem(this.storageKey + '_image_data');
      if (savedImageData) {
        const img = document.getElementById('char-img');
        if (img) {
          img.src = savedImageData;
          img.style.display = 'block';
        }
      }

      // Load created attacks
      const savedAttacks = localStorage.getItem(this.storageKey + '_attacks');
      if (savedAttacks) {
        document.getElementById('ataque-criado').innerHTML = savedAttacks;
      }

      return true;
    } catch (error) {
      console.error('Error loading character data:', error);
      return false;
    }
  }

  /**
   * Show save indicator with message
   */
  showSaveIndicator(message, type = 'success') {
    if (!this.saveIndicator || !this.saveText) return;

    // Update text
    this.saveText.textContent = message;

    // Remove existing classes
    this.saveIndicator.classList.remove('saving', 'error');
    
    // Add appropriate class
    if (type === 'saving') {
      this.saveIndicator.classList.add('saving');
    } else if (type === 'error') {
      this.saveIndicator.classList.add('error');
    }

    // Show indicator
    this.saveIndicator.classList.add('show');

    // Hide after 3 seconds (except for error messages)
    if (type !== 'error') {
      setTimeout(() => {
        this.saveIndicator.classList.remove('show');
      }, 3000);
    }
  }

  /**
   * Clear all character data
   */
  clearCharacterData() {
    if (confirm('Tem certeza que deseja limpar todos os dados do personagem? Esta ação não pode ser desfeita.')) {
      localStorage.removeItem(this.storageKey);
      this.form.reset();
      this.showSaveIndicator('Dados limpos');
    }
  }

  /**
   * Export character data as JSON
   */
  exportCharacterData() {
    const savedData = localStorage.getItem(this.storageKey);
    if (!savedData) {
      alert('Nenhum dado para exportar.');
      return;
    }

    const characterData = JSON.parse(savedData);
    const dataStr = JSON.stringify(characterData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `personagem_curserd_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  }

  /**
   * Import character data from JSON file
   */
  importCharacterData(file) {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const characterData = JSON.parse(e.target.result);
        localStorage.setItem(this.storageKey, JSON.stringify(characterData));
        this.loadCharacterData();
        this.showSaveIndicator('Dados importados com sucesso');
      } catch (error) {
        console.error('Error importing character data:', error);
        alert('Erro ao importar dados. Verifique se o arquivo é válido.');
      }
    };
    
    reader.readAsText(file);
  }

}

// Funções globais para o HTML
function rollDice(sides) {
  const result = Math.floor(Math.random() * sides) + 1;
  document.getElementById("dice-result").innerText = `Resultado do d${sides}: ${result}`;
}

function loadImage(event) {
  const reader = new FileReader();
  reader.onload = function() {
    const img = document.getElementById('char-img');
    img.src = reader.result;
    img.style.display = 'block';
    
    // Save image data to localStorage
    localStorage.setItem('curserd_character_sheet_image_data', reader.result);
    
    // Trigger save indicator
    if (window.characterSheet) {
      window.characterSheet.showSaveIndicator('Imagem salva', 'success');
    }
  }
  
  if (event.target.files[0]) {
    reader.readAsDataURL(event.target.files[0]);
  }
}

function criarAtaque() {
  const nome = document.getElementById('nomeAtaque').value;
  const dano = document.getElementById('danoAtaque').value;
  const acerto = document.getElementById('acertoAtaque').value;
  
  if (!nome || !dano || !acerto) {
    alert('Preencha todos os campos do ataque!');
    return;
  }
  
  const ataqueDiv = document.getElementById('ataque-criado');
  const novoAtaque = document.createElement('div');
  novoAtaque.style.cssText = 'border: 1px solid #6c40aa; padding: 10px; margin: 5px 0; border-radius: 5px; background: #2a2a40;';
  novoAtaque.innerHTML = `
    <strong>${nome}</strong><br>
    Dano: ${dano}<br>
    Acerto: ${acerto}
    <button type="button" onclick="this.parentElement.remove(); salvarAtaques();" style="float: right; background: #aa4040; padding: 5px;">Remover</button>
  `;
  
  ataqueDiv.appendChild(novoAtaque);
  
  // Limpar campos
  document.getElementById('nomeAtaque').value = '';
  document.getElementById('danoAtaque').value = '';
  document.getElementById('acertoAtaque').value = '';
  
  // Salvar ataques
  salvarAtaques();
}

function salvarAtaques() {
  const ataques = document.getElementById('ataque-criado').innerHTML;
  localStorage.setItem('curserd_character_sheet_attacks', ataques);
  
  if (window.characterSheet) {
    window.characterSheet.showSaveIndicator('Ataques salvos', 'success');
  }
}

// Função para exportar dados da ficha
function exportCharacterData() {
  const characterData = {};
  const form = document.getElementById('characterForm');
  
  if (!form) return;
  
  // Coletar dados do formulário
  const formData = new FormData(form);
  for (let [key, value] of formData.entries()) {
    characterData[key] = value;
  }
  
  // Incluir dados extras
  characterData.imageData = localStorage.getItem('curserd_character_sheet_image_data');
  characterData.attacks = localStorage.getItem('curserd_character_sheet_attacks');
  characterData.exportDate = new Date().toISOString();
  
  // Criar arquivo para download
  const dataStr = JSON.stringify(characterData, null, 2);
  const dataBlob = new Blob([dataStr], {type: 'application/json'});
  
  const link = document.createElement('a');
  link.href = URL.createObjectURL(dataBlob);
  link.download = `ficha_${characterData.nome || 'personagem'}_${new Date().toISOString().split('T')[0]}.json`;
  link.click();
  
  if (window.characterSheet) {
    window.characterSheet.showSaveIndicator('Ficha exportada!', 'success');
  }
}

// Função para importar dados da ficha
function importCharacterData(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const characterData = JSON.parse(e.target.result);
      
      // Restaurar dados do formulário
      Object.entries(characterData).forEach(([key, value]) => {
        const element = document.querySelector(`[name="${key}"]`);
        if (element && key !== 'imageData' && key !== 'attacks' && key !== 'exportDate') {
          element.value = value;
        }
      });
      
      // Restaurar imagem
      if (characterData.imageData) {
        const img = document.getElementById('char-img');
        if (img) {
          img.src = characterData.imageData;
          img.style.display = 'block';
        }
        localStorage.setItem('curserd_character_sheet_image_data', characterData.imageData);
      }
      
      // Restaurar ataques
      if (characterData.attacks) {
        const ataqueDiv = document.getElementById('ataque-criado');
        if (ataqueDiv) {
          ataqueDiv.innerHTML = characterData.attacks;
        }
        localStorage.setItem('curserd_character_sheet_attacks', characterData.attacks);
      }
      
      // Salvar todos os dados
      if (window.characterSheet) {
        window.characterSheet.saveCharacterData();
        window.characterSheet.showSaveIndicator('Ficha importada com sucesso!', 'success');
      }
      
    } catch (error) {
      alert('Erro ao importar arquivo. Verifique se é um arquivo de ficha válido.');
      console.error('Erro na importação:', error);
    }
  };
  
  reader.readAsText(file);
  
  // Limpar input
  event.target.value = '';
}

// Função para limpar todos os dados (caso necessário)
function limparDados() {
  if (confirm('Tem certeza que deseja limpar todos os dados? Esta ação não pode ser desfeita.')) {
    // Limpar todos os dados relacionados
    localStorage.removeItem('curserd_character_sheet');
    localStorage.removeItem('curserd_character_sheet_image_data');
    localStorage.removeItem('curserd_character_sheet_image_name');
    localStorage.removeItem('curserd_character_sheet_attacks');
    
    // Reset form
    document.getElementById('characterForm').reset();
    
    // Reset image
    const img = document.getElementById('char-img');
    if (img) {
      img.src = '';
      img.style.display = 'none';
    }
    
    // Reset attacks
    const ataqueDiv = document.getElementById('ataque-criado');
    if (ataqueDiv) {
      ataqueDiv.innerHTML = '';
    }
    
    // Reset default values
    ['forca', 'destreza', 'constituicao', 'intelecto', 'presenca', 'maldicao'].forEach(attr => {
      const element = document.getElementById(attr);
      if (element) element.value = '1';
    });
    
    if (window.characterSheet) {
      window.characterSheet.showSaveIndicator('Dados limpos');
    }
  }
}

// Initialize character sheet when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.characterSheet = new CharacterSheet();
  
  // Add keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    // Ctrl+S to save
    if (e.ctrlKey && e.key === 's') {
      e.preventDefault();
      window.characterSheet.saveCharacterData();
      window.characterSheet.showSaveIndicator('Dados salvos manualmente');
    }
    
    // Ctrl+Shift+C to clear
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
      e.preventDefault();
      window.characterSheet.clearCharacterData();
    }
  });
});

// Expose utility functions to global scope for potential console use
window.exportCharacter = () => window.characterSheet.exportCharacterData();
window.clearCharacter = () => window.characterSheet.clearCharacterData();
